self.__precacheManifest = [
  {
    "revision": "64e50dc88ea4b6a54439",
    "url": "/static/css/main.a27a3272.chunk.css"
  },
  {
    "revision": "64e50dc88ea4b6a54439",
    "url": "/static/js/main.8ee9761f.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "0315fd2db8625945b72c",
    "url": "/static/css/2.83ba3feb.chunk.css"
  },
  {
    "revision": "0315fd2db8625945b72c",
    "url": "/static/js/2.7b959e3e.chunk.js"
  },
  {
    "revision": "34a28a995b3afa421841b8bd258ba5b2",
    "url": "/index.html"
  }
];